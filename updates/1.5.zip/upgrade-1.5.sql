ALTER TABLE `notes` CHANGE `deleted` `deleted` TINYINT(1) NOT NULL DEFAULT '0';#

ALTER TABLE `expenses` CHANGE `deleted` `deleted` TINYINT(1) NOT NULL DEFAULT '0';#

ALTER TABLE `settings` CHANGE `deleted` `deleted` TINYINT(1) NOT NULL DEFAULT '0';#

ALTER TABLE `expenses` ADD `files` MEDIUMTEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL AFTER `amount`;#

INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES
('disable_client_login', '', 0),
('disable_client_signup', '', 0);

update settings as new_settings
inner join ( select setting_value from settings where setting_name = 'disable_client_login_and_signup') as old_settigns
set new_settings.setting_value = old_settigns.setting_value
where new_settings.setting_name='disable_client_login' OR new_settings.setting_name='disable_client_signup';#