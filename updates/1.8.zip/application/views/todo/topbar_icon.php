<?php if (get_setting("module_todo")) { ?>
    <li class="todo-top-icon">
        <a href="<?php echo_uri('todo'); ?>" class="dropdown-toggle"><i class="fa fa-check-square-o"></i></a>
    </li>
<?php } ?>
