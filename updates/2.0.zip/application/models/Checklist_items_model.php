<?php

class Checklist_items_model extends Crud_model {

    private $table = null;

    function __construct() {
        $this->table = 'checklist_items';
        parent::__construct($this->table);
    }
    
}