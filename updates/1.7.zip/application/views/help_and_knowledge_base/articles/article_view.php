<h2 class="mb20 pb10 b-b"> <?php echo $article_info->title; ?></h2>
<div>
    <?php echo $article_info->description; ?>
</div>

