<?php

$upgrade_sql = "upgrade-1.7.sql";
$sql = file_get_contents($upgrade_sql);

//create tables in database 
foreach (explode(";#", $sql) as $query) {
    $query = trim($query);
    if ($query) {
        try {
            $this->db->query($query);
        } catch (Exception $exc) {
            echo $exc->getTraceAsString();
        }
    }
}

try {

    //add data to the new items table from the invoice_items and estimates_items
    $this->db->query("SET sql_mode = ''");

    $items_sql = "SELECT title, MAX(description) AS description, MAX(unit_type) AS unit_type, MAX(rate) as rate FROM
                  ((SELECT title, MAX(description) AS description, MAX(unit_type) AS unit_type, MAX(rate) as rate FROM `invoice_items` WHERE deleted = 0 GROUP BY title)
                  UNION
                  (SELECT title, MAX(description) AS description, MAX(unit_type) AS unit_type, MAX(rate) as rate FROM `estimate_items` WHERE deleted = 0 GROUP BY title)) AS new_table1
                  GROUP BY new_table1.title";

    $invoice_items = $this->db->query($items_sql)->result();
    foreach ($invoice_items as $item) {
        $title = $item->title;
        $description = $item->description ? $item->description : "";
        $unit_type = $item->unit_type ? $item->unit_type : "";
        $rate = $item->rate ? $item->rate : 0;

        $this->db->query("INSERT INTO `items` (`title`, `description`, `unit_type`, `rate`, `deleted`) VALUES ( '$title', '$description', '$unit_type', '$rate', '0');");
    }
} catch (Exception $exc) {
    echo $exc->getTraceAsString();
}

unlink($upgrade_sql);
