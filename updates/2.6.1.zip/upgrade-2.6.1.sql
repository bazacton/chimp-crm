CREATE TABLE IF NOT EXISTS `item_categories` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`title` text COLLATE utf8_unicode_ci NOT NULL,
`deleted` tinyint(1) NOT NULL DEFAULT '0',
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;#

INSERT INTO `item_categories` (`id`, `title`, `deleted`) VALUES
(1, 'General item', 0);#

ALTER TABLE `items` ADD `category_id` INT(11) NOT NULL AFTER `show_in_client_portal`;#