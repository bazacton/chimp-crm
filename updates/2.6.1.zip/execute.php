<?php

$upgrade_sql = "upgrade-2.6.1.sql";
$sql = file_get_contents($upgrade_sql);

//create tables in database 
foreach (explode(";#", $sql) as $query) {
    $query = trim($query);
    if ($query) {
        try {
            $this->db->query($query);
        } catch (Exception $exc) {
            echo $exc->getTraceAsString();
        }
    }
}

unlink($upgrade_sql);
