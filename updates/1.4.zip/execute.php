<?php

$upgrade_sql = "upgrade-1.4.sql";
$sql = file_get_contents($upgrade_sql);

//create tables in database 
foreach (explode(";#", $sql) as $query) {
    $query = trim($query);
    if ($query) {
        try {
            $this->db->query($query);
        } catch (Exception $exc) {
            echo $exc->getTraceAsString();
        }
    }
}

unlink($upgrade_sql);

try {
	unlink("\assets\js\slimscroll\jquery.slimscroll.js");
	unlink("\assets\js\slimscroll\jquery.slimscroll.min.js");
	unlink("\assets\js\slimscroll\README.md");
} catch (Exception $e) {
}


