
ALTER TABLE `projects` CHANGE `start_date` `start_date` DATE NULL, CHANGE `deadline` `deadline` DATE NULL, CHANGE `created_date` `created_date` DATE NULL;#

UPDATE `projects` SET `created_date`= NULL WHERE `created_date` = '0000-00-00';#

UPDATE `projects` SET `start_date`= NULL WHERE `start_date` = '0000-00-00';#

UPDATE `projects` SET `deadline`= NULL WHERE `deadline` = '0000-00-00';#



ALTER TABLE `invoices` CHANGE `next_recurring_date` `next_recurring_date` DATE NULL DEFAULT NULL, CHANGE `due_reminder_date` `due_reminder_date` DATE NULL DEFAULT NULL, CHANGE `recurring_reminder_date` `recurring_reminder_date` DATE NULL DEFAULT NULL;#

UPDATE `invoices` SET `next_recurring_date`= NULL WHERE `next_recurring_date` = '0000-00-00';#

UPDATE `invoices` SET `due_reminder_date`= NULL WHERE `due_reminder_date` = '0000-00-00';#

UPDATE `invoices` SET `recurring_reminder_date`= NULL WHERE `recurring_reminder_date` = '0000-00-00';#



ALTER TABLE `team_member_job_info` CHANGE `date_of_hire` `date_of_hire` DATE NULL DEFAULT NULL;#

UPDATE `team_member_job_info` SET `date_of_hire`= NULL WHERE `date_of_hire` = '0000-00-00';#



ALTER TABLE `users` CHANGE `message_checked_at` `message_checked_at` DATETIME NULL DEFAULT NULL, CHANGE `notification_checked_at` `notification_checked_at` DATETIME NULL DEFAULT NULL, CHANGE `dob` `dob` DATE NULL DEFAULT NULL, CHANGE `created_at` `created_at` DATETIME NULL DEFAULT NULL;#

UPDATE `users` SET `message_checked_at`= NULL WHERE `message_checked_at` = '0000-00-00 00:00:00';#

UPDATE `users` SET `notification_checked_at`= NULL WHERE `notification_checked_at` = '0000-00-00 00:00:00';#

UPDATE `users` SET `created_at`= NULL WHERE `created_at` = '0000-00-00 00:00:00';#

UPDATE `users` SET `dob`= NULL WHERE `dob` = '0000-00-00';#



ALTER TABLE `tasks` CHANGE `start_date` `start_date` DATE NULL DEFAULT NULL;#

UPDATE `tasks` SET `start_date`= NULL WHERE `start_date` = '0000-00-00';#


ALTER TABLE `tasks` CHANGE `deadline` `deadline` DATE NULL DEFAULT NULL;#

UPDATE `tasks` SET `deadline`= NULL WHERE `deadline` = '0000-00-00';#


ALTER TABLE `to_do` CHANGE `start_date` `start_date` DATE NULL DEFAULT NULL;#

UPDATE `to_do` SET `start_date`= NULL WHERE `start_date` = '0000-00-00';#