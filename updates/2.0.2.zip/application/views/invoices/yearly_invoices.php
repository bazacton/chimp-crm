 <table id="yearly-invoice-table" class="display" cellspacing="0" width="100%">   
            </table>
<script type="text/javascript">
    $(document).ready(function () {
        loadInvoicesTable("#yearly-invoice-table", "yearly");
    });
</script>