
ALTER TABLE `invoices` CHANGE `due_reminder_date` `due_reminder_date` DATE NOT NULL, CHANGE `recurring_reminder_date` `recurring_reminder_date` DATE NOT NULL;#

ALTER TABLE `users` ADD `requested_account_removal` TINYINT(1) NOT NULL DEFAULT '0' AFTER `last_online`;#

INSERT INTO `notification_settings` (`id`, `event`, `category`, `enable_email`, `enable_web`, `notify_to_team`, `notify_to_team_members`, `notify_to_terms`, `sort`, `deleted`) VALUES (NULL, 'client_contact_requested_account_removal', 'client', '0', '0', '', '', '', '21', '0');#

CREATE TABLE IF NOT EXISTS `pages` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`title` text COLLATE utf8_unicode_ci,
`content` text COLLATE utf8_unicode_ci,
`slug` text COLLATE utf8_unicode_ci,
`status` enum('active','inactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
`deleted` int(1) NOT NULL DEFAULT '0',
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;#

CREATE TABLE IF NOT EXISTS `verification` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
`type` enum('invoice_payment','reset_password') COLLATE utf8_unicode_ci NOT NULL,
`code` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
`params` text COLLATE utf8_unicode_ci NOT NULL,
`deleted` int(1) NOT NULL DEFAULT '0',
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;#

ALTER TABLE `tasks` 
ADD `blocking` TEXT NOT NULL AFTER `created_date`,
ADD `blocked_by` TEXT NOT NULL AFTER `blocking`,
ADD `parent_task_id` INT(11) NOT NULL AFTER `blocking`;#

ALTER TABLE `custom_fields` ADD `disable_editing_by_clients` TINYINT(1) NOT NULL DEFAULT '0' AFTER `hide_from_clients`;#

ALTER TABLE `estimate_items` ADD `sort` INT(11) NOT NULL DEFAULT '0' AFTER `total`;#

INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('task_point_range', '5', '0');#

INSERT INTO `settings`(`setting_name`, `setting_value`, `deleted`) VALUES ('module_gantt', '1', 0);#

INSERT INTO `settings`(`setting_name`, `setting_value`, `deleted`) VALUES ('show_theme_color_changer', 'yes', 0);#



ALTER TABLE `invoices` ADD `tax_id3` INT(11) NOT NULL DEFAULT '0' AFTER `tax_id2`;#