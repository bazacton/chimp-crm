<div id="page-content" class="p20 clearfix">

    <div class="view-container">
        <?php echo nl2br($model_info->content); ?>
    </div>

</div>