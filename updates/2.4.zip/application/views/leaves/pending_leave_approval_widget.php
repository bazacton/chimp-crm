<div class="panel panel-orange">
    <a href="<?php echo get_uri('leaves/index'); ?>" class="white-link">
        <div class="panel-body">
            <div class="widget-icon">
                <i class="fa fa-sign-out"></i>
            </div>
            <div class="widget-details">
                <h1><?php echo $total; ?></h1>
                <?php echo lang("pending_leave_approval"); ?>
            </div>
        </div>
    </a>
</div>