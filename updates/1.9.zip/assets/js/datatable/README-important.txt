Added custom code in line#2287
Re-calculated the sLoopData;
