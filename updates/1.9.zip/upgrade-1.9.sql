
CREATE TABLE IF NOT EXISTS `client_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;#


ALTER TABLE `clients` ADD `group_ids` TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL AFTER `starred_by`;#


CREATE TABLE `task_status` ( 
  `id` INT NOT NULL AUTO_INCREMENT , 
  `title` VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL ,
  `key_name` VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL ,
  `color` VARCHAR(7) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL ,
  `sort` INT NOT NULL ,
  `deleted` TINYINT(1) NOT NULL DEFAULT '0' ,
  PRIMARY KEY (`id`)
 ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;#

 
INSERT INTO `task_status` (`id`, `title`, `key_name`, `color`, `sort`, `deleted`) VALUES ('1', 'To Do', 'to_do', '#F9A52D', '0', '0'), ('2', 'In progress', 'in_progress', '#1672B9', '1', '0'),  ('3', 'Done', 'done', '#00B393', '2', '0') ;#


ALTER TABLE `tasks` ADD `sort` DOUBLE NOT NULL DEFAULT '0' AFTER `collaborators`;#
ALTER TABLE `tasks` ADD `status_id` INT NOT NULL AFTER `status`;#


UPDATE `tasks` SET `status_id`=3 WHERE status = 'done';#
UPDATE `tasks` SET `status_id`=2 WHERE status = 'in_progress';#
UPDATE `tasks` SET `status_id`=1 WHERE status != 'done' AND status != 'in_progress';#
UPDATE `tasks` SET `sort`=id*100000 ;#


ALTER TABLE `projects` CHANGE `status` `status` ENUM('open','completed','hold','canceled') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open';#


ALTER TABLE `estimate_forms` ADD `public` TINYINT(1) NOT NULL DEFAULT '0' AFTER `status`;#


ALTER TABLE `estimate_requests` ADD `lead_id` INT NOT NULL DEFAULT '0' AFTER `client_id`;#


ALTER TABLE `events` ADD `recurring` INT(1) NOT NULL DEFAULT '0' AFTER `color`, ADD `repeat_every` INT NOT NULL DEFAULT '0' AFTER `recurring`, ADD `repeat_type` ENUM('days', 'weeks', 'months', 'years') NULL DEFAULT NULL AFTER `repeat_every`, ADD `no_of_cycles` INT NOT NULL DEFAULT '0' AFTER `repeat_type`, ADD `last_start_date` DATE NULL DEFAULT NULL AFTER `no_of_cycles`, ADD `recurring_dates` LONGTEXT NOT NULL AFTER `last_start_date`;#


CREATE TABLE IF NOT EXISTS `leads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `city` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zip` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_date` date NOT NULL,
  `website` text COLLATE utf8_unicode_ci,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;#