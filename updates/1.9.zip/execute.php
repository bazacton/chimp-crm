<?php

$upgrade_sql = "upgrade-1.9.sql";
$sql = file_get_contents($upgrade_sql);

//create tables in database 
foreach (explode(";#", $sql) as $query) {
    $query = trim($query);
    if ($query) {
        try {
            $this->db->query($query);
        } catch (Exception $exc) {
            echo $exc->getTraceAsString();
        }
    }
}

//There was a bug in existing upgrade script.
//So set the folder permission manually.

chmod("./application/views/client_groups", 0755);
chmod("./application/views/request_estimate", 0755);
chmod("./application/views/task_status", 0755);
chmod("./assets/css/color", 0755);


unlink($upgrade_sql);
