<?php

/* Please extend your controllers from MY_Controller, instead of Pre_loader.
 * We'll remove this in future update.
 */

class Pre_loader extends MY_Controller {

    function __construct() {
        parent::__construct();
    }

}
