<style>
    .status{
        font-size: 20px;
    }
    .status{
        font-size: 20px;
    }
    .status.fa-check-circle-o{
        color: #00b393;
    }
    .status.fa-times-circle-o{
        color: #d73b3b;
    }
    table{
        width: 100%;
    }
    th, td{
        padding:5px 0;
    }
    hr{
        margin: 10px 0 0;
    }
    .section{
        margin-bottom: 30px;
    }
    .section:last-child{
        margin-bottom: 0;
    }
</style>

<div class="panel font-14">
    <div class="panel-body">
        <div class="section">
            <p>1. Please configure your PHP settings to match following requirements:</p>
            <hr />
            <div>
                <table>
                    <thead>
                        <tr>
                            <th width="25%">PHP Settings</th>
                            <th width="27%">Current Version</th>
                            <th>Required Version</th>
                            <th class="text-center">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>PHP Version</td>
                            <td><?php echo $current_php_version; ?></td>
                            <td><?php echo $php_version_required; ?>+</td>
                            <td class="text-center">
                                <?php if ($php_version_success) { ?>
                                    <i class="status fa fa-check-circle-o"></i>
                                <?php } else { ?>
                                    <i class="status fa fa-times-circle-o"></i>
                                <?php } ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="section">
            <p>2. Please make sure the extensions/settings listed below are installed/enabled:</p>
            <hr />
            <div>
                <table>
                    <thead>
                        <tr>
                            <th width="25%">Extension/settings</th>
                            <th width="27%">Current Settings</th>
                            <th>Required Settings</th>
                            <th class="text-center">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>MySQLi</td>
                            <td> <?php if ($mysql_success) { ?>
                                    On
                                <?php } else { ?>
                                    Off
                                <?php } ?>
                            </td>
                            <td>On</td>
                            <td class="text-center">
                                <?php if ($mysql_success) { ?>
                                    <i class="status fa fa-check-circle-o"></i>
                                <?php } else { ?>
                                    <i class="status fa fa-times-circle-o"></i>
                                <?php } ?>
                            </td>
                        </tr>
                        <tr>
                            <td>GD</td>
                            <td> <?php if ($gd_success) { ?>
                                    On
                                <?php } else { ?>
                                    Off
                                <?php } ?>
                            </td>
                            <td>On</td>
                            <td class="text-center">
                                <?php if ($gd_success) { ?>
                                    <i class="status fa fa-check-circle-o"></i>
                                <?php } else { ?>
                                    <i class="status fa fa-times-circle-o"></i>
                                <?php } ?>
                            </td>
                        </tr>
                        <tr>
                            <td>cURL</td>
                            <td> <?php if ($curl_success) { ?>
                                    On
                                <?php } else { ?>
                                    Off
                                <?php } ?>
                            </td>
                            <td>On</td>
                            <td class="text-center">
                                <?php if ($curl_success) { ?>
                                    <i class="status fa fa-check-circle-o"></i>
                                <?php } else { ?>
                                    <i class="status fa fa-times-circle-o"></i>
                                <?php } ?>
                            </td>
                        </tr>
                        <tr>
                            <td>mbstring</td>
                            <td> <?php if ($mbstring_success) { ?>
                                    On
                                <?php } else { ?>
                                    Off
                                <?php } ?>
                            </td>
                            <td>On</td>
                            <td class="text-center">
                                <?php if ($mbstring_success) { ?>
                                    <i class="status fa fa-check-circle-o"></i>
                                <?php } else { ?>
                                    <i class="status fa fa-times-circle-o"></i>
                                <?php } ?>
                            </td>
                        </tr>
                        <tr>
                            <td>intl</td>
                            <td> <?php if ($intl_success) { ?>
                                    On
                                <?php } else { ?>
                                    Off
                                <?php } ?>
                            </td>
                            <td>On</td>
                            <td class="text-center">
                                <?php if ($intl_success) { ?>
                                    <i class="status fa fa-check-circle-o"></i>
                                <?php } else { ?>
                                    <i class="status fa fa-times-circle-o"></i>
                                <?php } ?>
                            </td>
                        </tr>
                        <tr>
                            <td>json</td>
                            <td> <?php if ($json_success) { ?>
                                    On
                                <?php } else { ?>
                                    Off
                                <?php } ?>
                            </td>
                            <td>On</td>
                            <td class="text-center">
                                <?php if ($json_success) { ?>
                                    <i class="status fa fa-check-circle-o"></i>
                                <?php } else { ?>
                                    <i class="status fa fa-times-circle-o"></i>
                                <?php } ?>
                            </td>
                        </tr>
                        <tr>
                            <td>mysqlnd</td>
                            <td> <?php if ($mysqlnd_success) { ?>
                                    On
                                <?php } else { ?>
                                    Off
                                <?php } ?>
                            </td>
                            <td>On</td>
                            <td class="text-center">
                                <?php if ($mysqlnd_success) { ?>
                                    <i class="status fa fa-check-circle-o"></i>
                                <?php } else { ?>
                                    <i class="status fa fa-times-circle-o"></i>
                                <?php } ?>
                            </td>
                        </tr>
                        <tr>
                            <td>xml</td>
                            <td> <?php if ($xml_success) { ?>
                                    On
                                <?php } else { ?>
                                    Off
                                <?php } ?>
                            </td>
                            <td>On</td>
                            <td class="text-center">
                                <?php if ($xml_success) { ?>
                                    <i class="status fa fa-check-circle-o"></i>
                                <?php } else { ?>
                                    <i class="status fa fa-times-circle-o"></i>
                                <?php } ?>
                            </td>
                        </tr>
                        <tr>
                            <td>date.timezone</td>
                            <td> <?php
                                if ($timezone_success) {
                                    echo $timezone_settings;
                                } else {
                                    echo "Null";
                                }
                                ?>
                            </td>
                            <td>Timezone</td>
                            <td class="text-center">
                                <?php if ($timezone_success) { ?>
                                    <i class="status fa fa-check-circle-o"></i>
                                <?php } else { ?>
                                    <i class="status fa fa-times-circle-o"></i>
                                <?php } ?>
                            </td>
                        </tr>

                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>