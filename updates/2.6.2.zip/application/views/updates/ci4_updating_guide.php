<p>
    Follow this guideline to install the version - <strong>2.7</strong>
</p>

<hr />

<p>
    In 2.7, the one click installation will not work. We've upgraded Codeigniter version from 3 to 4. Since they've updated everything along with directory structure, it requires some custom approaches to accomplish. Please follow this steps carefully.
</p>
<ol>
	<li>You must backup your database and files in a secure place.</li>
    <li>Please check the server requirements at the bottom of this page and make sure everything is OK.</li>
	<li>Copy this instructions to a text pad or somewhere else. You may will not see this page.</li>  
    <li>Move all the files and folders of RISE in a new folder named BACKUP. (Files and folders: index.php, application, assets, files, system and updates)</li>
                      
    <li>Now go the \BACKUP\updates\ folder and copy <b>2.7.zip</b> to root directory (The same place, from where you've copied the index.php).</li> 
    <li>Extract the 2.7.zip.</li>
    <li>Copy the value of <b>encryption_key</b> from <b>\BACKUP\application\config\config.php</b>. Now go to new directory <b>...\app\Config\App.php</b> and find <b>enter_encryption_key</b>, paste the value there and save.</li>
    <li>Copy your database configuration from old <b>\BACKUP\application\config\database.php</b> to <b>...\app\Config\Database.php</b> (Find the values: enter_hostname, enter_db_username, enter_db_password, enter_database_name)</li>
    <li>If you've any custom config in <b>\BACKUP\application\config\config.php</b>, add those at the end of this file or find associated configs in: <b>...\app\Config\App.php</b>. If you have the base_url config, remember to set that in $baseURL varialbe.</li>
    <li>If you've any custom language, add to <b>...\app\Language\[your_language]\custom_lang.php</b></li>
    <li>Copy the old <b>\BACKUP\files</b> to <b>...\files</b></li>
    <li>Now, load this link: <b><a href="<?php echo_uri("execute_ci4"); ?>" target="_blank"><?php echo_uri("execute_ci4"); ?></a></b> in a new tab. If everything is all right, it'll load as like before.</li>
    <li>If you use <b>SMTP</b> in Settings > App Settings > Email, please re-enter the password and save.</li>
    <li>If you have enabled <b>IMAP</b> in Settings > Setup > Tickets > IMAP settings, please re-enter the password and authorize.</li>
    <li>If you have any custom css in <b>BACKUP\assets\css\custom-style.css</b>, those may will not work with the new UI. So, please check the css and change accordingly.</li>
	<li>If everything is OK, download the BACKUP and remove that from your server. Remove the 2.7.zip.</li>
	<li>Login to your dashboard and change the Theme color from Settings>App Settings>General settings page. Upload transparent background logos everywhere.</li>
</ol>