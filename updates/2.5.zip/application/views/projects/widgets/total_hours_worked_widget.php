<div class="panel panel-default">
    <div class="panel-body">
        <div class="widget-icon">
            <i class="fa fa-clock-o"></i>
        </div>
        <div class="widget-details">
            <h1><?php echo $total_project_hours; ?></h1>
            <?php echo lang("total_hours_worked"); ?>
        </div>
    </div>
</div>