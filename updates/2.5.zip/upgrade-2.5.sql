
CREATE TABLE IF NOT EXISTS `labels` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`title` text COLLATE utf8_unicode_ci NOT NULL,
`color` VARCHAR(15) NOT NULL,
`context` enum('event','invoice','note','project','task','ticket','to_do') COLLATE utf8_unicode_ci DEFAULT NULL,
`user_id` int(11) NOT NULL DEFAULT '0',
`deleted` int(1) NOT NULL DEFAULT '0',
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;#


ALTER TABLE `verification` CHANGE `type` `type` ENUM('invoice_payment','reset_password','verify_email','invitation') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL;#


CREATE TABLE IF NOT EXISTS `stripe_ipn` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`payment_intent` TEXT NOT NULL,
`verification_code` TEXT NOT NULL,
`payment_verification_code` TEXT NOT NULL,
`invoice_id` int(11) NOT NULL,
`contact_user_id` int(11) NOT NULL,
`client_id` int(11) NOT NULL,
`payment_method_id` int(11) NOT NULL,
`deleted` tinyint(1) NOT NULL DEFAULT '0',
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;#


ALTER TABLE `users` CHANGE `gender` `gender` ENUM('male','female') CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL;#

ALTER TABLE `pages` ADD `internal_use_only` TINYINT(1) NOT NULL DEFAULT '0' AFTER `status`, ADD `visible_to_team_members_only` TINYINT(1) NOT NULL DEFAULT '0' AFTER `internal_use_only`, ADD `visible_to_clients_only` TINYINT(1) NOT NULL DEFAULT '0' AFTER `visible_to_team_members_only`;#


ALTER TABLE `expenses`
ADD `client_id` INT(11) NOT NULL DEFAULT '0' AFTER `title`,
ADD `recurring` tinyint(4) NOT NULL DEFAULT '0' AFTER `tax_id2`,
ADD `recurring_expense_id` tinyint(4) NOT NULL DEFAULT '0' AFTER `recurring`,
ADD `repeat_every` int(11) NOT NULL DEFAULT '0' AFTER `recurring_expense_id`,
ADD `repeat_type` enum('days','weeks','months','years') COLLATE utf8_unicode_ci DEFAULT NULL AFTER `repeat_every`,
ADD `no_of_cycles` int(11) NOT NULL DEFAULT '0' AFTER `repeat_type`,
ADD `next_recurring_date` date DEFAULT NULL AFTER `no_of_cycles`,
ADD `no_of_cycles_completed` int(11) NOT NULL DEFAULT '0' AFTER `next_recurring_date`;#

ALTER TABLE `invoices` ADD `files` MEDIUMTEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL AFTER `deleted`;#

ALTER TABLE `custom_fields` ADD `show_on_kanban_card` TINYINT(1) NOT NULL DEFAULT '0' AFTER `disable_editing_by_clients`;#

CREATE TABLE IF NOT EXISTS `likes` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`project_comment_id` int(11) NOT NULL,
`created_by` int(11) NOT NULL,
`created_at` datetime NOT NULL,
`deleted` tinyint(1) NOT NULL DEFAULT '0',
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;#


ALTER TABLE `tickets` ADD `requested_by` INT(11) NOT NULL DEFAULT '0' AFTER `created_by`;#


CREATE TABLE IF NOT EXISTS `ticket_templates` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`title` TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL ,
`description` mediumtext COLLATE utf8_unicode_ci NOT NULL ,
`ticket_type_id` INT(11) NOT NULL ,
`private` MEDIUMTEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL ,
`created_by` INT(11) NOT NULL ,
`created_at` DATETIME NOT NULL ,
`deleted` tinyint(1) NOT NULL DEFAULT '0',
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;#

INSERT INTO `email_templates` (`id`, `template_name`, `email_subject`, `default_message`, `custom_message`, `deleted`) VALUES (NULL, 'new_client_greetings', 'Welcome!', '<div style="background-color: #eeeeef; padding: 50px 0; ">    <div style="max-width:640px; margin:0 auto; ">  <div style="color: #fff; text-align: center; background-color:#33333e; padding: 30px; border-top-left-radius: 3px; border-top-right-radius: 3px; margin: 0;"><h1>Welcome to {COMPANY_NAME}</h1> </div> <div style="padding: 20px; background-color: rgb(255, 255, 255);">            <p><span style="color: rgb(85, 85, 85); font-size: 14px; line-height: 20px;">Hello {CONTACT_FIRST_NAME},</span></p><p><span style="color: rgb(85, 85, 85); font-size: 14px; line-height: 20px;">Thank you for creating your account. </span></p><p><span style="color: rgb(85, 85, 85); font-size: 14px; line-height: 20px;">We are happy to see you here.<br></span></p><hr><p style="color: rgb(85, 85, 85); font-size: 14px;">Dashboard URL:&nbsp;<a href="{DASHBOARD_URL}" target="_blank">{DASHBOARD_URL}</a></p><p style="color: rgb(85, 85, 85); font-size: 14px;"></p><p><span style="color: rgb(85, 85, 85); font-size: 14px; line-height: 20px;">Email: {CONTACT_LOGIN_EMAIL}</span><br></p><p><span style="color: rgb(85, 85, 85); font-size: 14px; line-height: 20px;">Password:&nbsp;{CONTACT_LOGIN_PASSWORD}</span></p><p style="color: rgb(85, 85, 85);"><br></p><p style="color: rgb(85, 85, 85); font-size: 14px;">{SIGNATURE}</p>        </div>    </div></div>', '', '0');#
INSERT INTO `email_templates` (`id`, `template_name`, `email_subject`, `default_message`, `custom_message`, `deleted`) VALUES (NULL, 'verify_email', 'Verify your email', '<div style="background-color: #eeeeef; padding: 50px 0; "><div style="max-width:640px; margin:0 auto; "><div style="color: #fff; text-align: center; background-color:#33333e; padding: 30px; border-top-left-radius: 3px; border-top-right-radius: 3px; margin: 0;"><h1>Account verification</h1></div><div style="padding: 20px; background-color: rgb(255, 255, 255); color:#555;"><p style="font-size: 14px;">To initiate the signup process, please click on the following link:<br></p><p style="font-size: 14px;"><br></p>', '', '0');#

ALTER TABLE `project_time` ADD `hours` FLOAT NOT NULL AFTER `end_time`;#

ALTER TABLE `notification_settings` ADD `enable_slack` INT(1) NOT NULL DEFAULT '0' AFTER `enable_web`;#


DELETE FROM `notification_settings` WHERE `notification_settings`.`event` = 'estimate_sent';#

INSERT INTO `notification_settings` (`id`, `event`, `category`, `enable_email`, `enable_web`, `notify_to_team`, `notify_to_team_members`, `notify_to_terms`, `sort`, `deleted`) VALUES (NULL, 'bitbucket_push_received', 'project', '0', '1', '', '', '', '45', '0');#
INSERT INTO `notification_settings` (`id`, `event`, `category`, `enable_email`, `enable_web`, `notify_to_team`, `notify_to_team_members`, `notify_to_terms`, `sort`, `deleted`) VALUES (NULL, 'github_push_received', 'project', '0', '1', '', '', '', '45', '0');#
INSERT INTO `notification_settings` (`id`, `event`, `category`, `enable_email`, `enable_web`, `notify_to_team`, `notify_to_team_members`, `notify_to_terms`, `sort`, `deleted`) VALUES (NULL, 'invited_client_contact_signed_up', 'client', '0', '0', '', '', '', '21', '0');#
INSERT INTO `notification_settings` (`id`, `event`, `category`, `enable_email`, `enable_web`, `notify_to_team`, `notify_to_team_members`, `notify_to_terms`, `sort`, `deleted`) VALUES (NULL, 'created_a_new_post', 'timeline', '0', '0', '', '', '', '52', '0');#
INSERT INTO `notification_settings` (`id`, `event`, `category`, `enable_email`, `enable_web`, `notify_to_team`, `notify_to_team_members`, `notify_to_terms`, `sort`, `deleted`) VALUES (NULL, 'timeline_post_commented', 'timeline', '0', '0', '', '', '', '52', '0');#
INSERT INTO `notification_settings` (`id`, `event`, `category`, `enable_email`, `enable_web`, `notify_to_team`, `notify_to_team_members`, `notify_to_terms`, `sort`, `deleted`) VALUES (NULL, 'ticket_assigned', 'ticket', '0', '0', '', '', 'ticket_assignee', '31', '0');#

ALTER TABLE `activity_logs` CHANGE `action` `action` ENUM('created','updated','deleted', 'bitbucket_notification_received', 'github_notification_received') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL;#
