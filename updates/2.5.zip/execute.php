<?php

$upgrade_sql = "upgrade-2.5.sql";
$sql = file_get_contents($upgrade_sql);

//create tables in database 
foreach (explode(";#", $sql) as $query) {
    $query = trim($query);
    if ($query) {
        try {
            $this->db->query($query);
        } catch (Exception $exc) {
            echo $exc->getTraceAsString();
        }
    }
}

$instance = $this;

function _get_all_labels($instance, $table) {
    $label_data = $instance->db->query("Select DISTINCT(labels) AS labels from $table")->result();
    $unique_labels = array();

    foreach ($label_data as $row) {
        if ($row->labels) {
            $labels_array = explode(",", $row->labels);
            if (is_array($labels_array)) {
                foreach ($labels_array as $row_lable) {
                    array_push($unique_labels, trim($row_lable));
                }
            }
        }
    }
    $unique_labels = array_unique($unique_labels);
    return array($unique_labels, $label_data);
}

function _get_all_labels_user_wise($instance, $table) {
    $label_data = $instance->db->query("SELECT created_by, labels FROM $table GROUP BY labels,created_by")->result();
    $unique_labels = array();

    foreach ($label_data as $row) {
        if ($row->labels) {
            $labels_array = explode(",", $row->labels);
            if (is_array($labels_array)) {
                foreach ($labels_array as $row_lable) {

                    $user_id = $row->created_by;
                    $unique_labels[$user_id][] = trim($row_lable);
                }
            }
        }
    }

    //make unique
    foreach ($unique_labels as $user_id => $task_label) {
        $unique_labels[$user_id] = array_unique($task_label);
    }

    return array($unique_labels, $label_data);
}

function _get_new_labels_list($instance, $all_labels, $context, $user_id = 0) {
    $new_labels_list = array();

    foreach ($all_labels as $label) {
        $data = array("title" => $label, "color" => "#37b4e1", "context" => $context, "user_id" => $user_id);
        $save = $instance->db->insert("labels", $data);
        if ($save) {
            $insert_id = $instance->db->insert_id();
            $new_labels_list[$label] = $insert_id;
        }
    }
    return $new_labels_list;
}

function _update_existing_labels($instance, $all_labels, $new_labels_list, $table, $created_by = 0) {
    //prepare the ids for the existing data. 
    foreach ($all_labels as $row) {

        if ($row->labels) {
            $labels_array = explode(",", $row->labels);
            if (is_array($labels_array)) {
                $final_label_ids = "";

                foreach ($labels_array as $lable) {
                    if ($final_label_ids) {
                        $final_label_ids .= ",";
                    }
                    $final_label_ids .= get_array_value($new_labels_list, $lable);
                }

                $data = array("labels" => $final_label_ids);
                $where = array("labels" => $row->labels);
                if ($created_by) {
                    $where["created_by"] = $created_by;
                }

                $instance->db->update($table, $data, $where);
            }
        }
    }
}

$this->db->query("SET sql_mode = ''"); //ignor sql mode here
//update public/common labels 

$contexts = array(
    "task",
    "project",
    "ticket",
    "invoice",
);

foreach ($contexts as $context) {
    $table = $context . "s";

    $labels_result = _get_all_labels($instance, $table);
    $new_labels_list = _get_new_labels_list($instance, $labels_result[0], $context);
    _update_existing_labels($instance, $labels_result[1], $new_labels_list, $table);
}



//update private labels 

$contexts = array(
    "event",
    "note",
    "to_do"
);

foreach ($contexts as $context) {

    $table = ($context == "to_do") ? $context : ($context . "s");
    $labels_result = _get_all_labels_user_wise($instance, $table);

    //insert into database
    foreach ($labels_result[0] as $user_id => $user_label) {
        $new_labels_list = _get_new_labels_list($instance, $user_label, $context, $user_id);
        _update_existing_labels($instance, $labels_result[1], $new_labels_list, $table, $user_id);
    }
}



unlink($upgrade_sql);
